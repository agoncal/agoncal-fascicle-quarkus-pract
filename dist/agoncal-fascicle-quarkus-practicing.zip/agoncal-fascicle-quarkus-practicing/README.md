# agoncal-fascicle-quarkus-pract

Code of my future Practicing Quarkus Fascicle
