# agoncal-fascicle-quarkus-pract

Code of my future Practising Quarkus Fascicle
